-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2019 at 05:48 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_db`
--

-- --------------------------------------------------------

-- Table users
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- Table Client
CREATE TABLE Client (
    id_client INT PRIMARY KEY AUTO_INCREMENT,
    nom_client VARCHAR(100)NOT NULL,
    prenom VARCHAR(200)NOT NULL,
    email VARCHAR(200) NOT NULL,
    telephone VARCHAR(20)NOT NULL,
    adresse VARCHAR(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table Fournisseur
CREATE TABLE Fournisseur (
    id_fournisseur INT PRIMARY KEY AUTO_INCREMENT,
    nom_fournisseur VARCHAR(100) NOT NULL,
    telephone VARCHAR(14) NOT NULL,
    adresse VARCHAR(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table Produit
CREATE TABLE Produit (
    id_produit INT PRIMARY KEY AUTO_INCREMENT,
    nom_produit VARCHAR(100) NOT NULL, 
    type VARCHAR(50) NOT NULL,
    quantite_stock INT NOT NULL,
    id_fournisseur INT,
    prix_unitaire DECIMAL(10, 2) NOT NULL,
    image VARCHAR(300) NOT NULL,
    FOREIGN KEY (id_fournisseur) REFERENCES Fournisseur(id_fournisseur)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table Commande
CREATE TABLE Commande (
    id_commande INT PRIMARY KEY AUTO_INCREMENT,
    id_client INT,
    date_commande DATETIME NOT NULL,
    date_livraison DATETIME NOT NULL,
    statut VARCHAR(50) NOT NULL,
    FOREIGN KEY (id_client) REFERENCES Client(id_client)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Table Achat
CREATE TABLE Achat (
    id_produit INT,
    id_commande INT,
    quantite_achat INT NOT NULL,
    prix_total DECIMAL(10, 2) NOT NULL,
    CONSTRAINT AchatPK PRIMARY KEY (id_produit, id_commande),     
    FOREIGN KEY (id_produit) REFERENCES Produit(id_produit),
    FOREIGN KEY (id_commande) REFERENCES Commande(id_commande)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



/*---------------------------------------------------------------- insertion des donnees -----------------------------------------------------------------*/
-- Contenu de la table users
INSERT INTO `users` (`id`, `user_name`, `password`, `name`) VALUES
(1, 'elias', '123', 'Elias'),
(2, 'john', 'abc', 'John');


-- Contenu de la table client
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (1,'Alfreds', 'Ferki', 'ferki@gmail.com', '07.63.07.43.21', 'Azazga au quartier les Chalets');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (2,'Antonio', 'Mohen Taquería', 'antonioss@outlook.com', '06.67.39.32', 'Yakouren à côté de la mosquée');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (3,'Amiroche', 'Heddd', 'heddad22@outlook.com', '06.35.44.77.88', 'Azazga Tizi Bouchen');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (4,'Piter','Berglund', 'berglund@gmail.com', '06.21.12.34.67', 'Tizi Ouzou Meqla la fontaine');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (5,'Hamid', 'Achur', 'achur100@gmail.com', '07.62.10.84.60', 'Azazga rue Al Mudjahidin');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (6,'Said', 'Si Mezien', 'simeziane@gmail.com', '05.55.51.99.39', 'Azazga rue 25 aout 1960');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (7,'Massi','Lebihan', 'lebihane59@gmail.com', '07.91.24.45.40', 'Tzi rue 12  Bouchers');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (8,'Hsen', 'Larabi', 'larabi@gmail.com', '06.45.55.47.29', 'Friha rue 23 Tsawassen Blvd.');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (9,'Madjid', 'Alouache', 'alouachei@gmail.com', '07.80.55.12.12', 'Cherfa Bahloul entrée');
INSERT INTO client (id_client, nom_client, prenom, email, telephone, adresse) VALUES (10,'Nasim', 'Aghrib', 'aghrib@gmail.com', '05.10.35.55.55', 'Fliki rue Cerrito');


-- Contenu de la table  fournisseur 
INSERT INTO  fournisseur (id_fournisseur, nom_fournisseur, telephone,  adresse) VALUES (1, 'OUAZAR BOIS', '06.89.55.22.22', 'Tizi Ouzou route d\'Alger');
INSERT INTO  fournisseur (id_fournisseur, nom_fournisseur, telephone,  adresse) VALUES (2, 'ALKA STORE EURL', '06.41.60.48.22', 'Tizi\-Ouzou rue Rahli Messouad M\'Douha');
INSERT INTO  fournisseur (id_fournisseur, nom_fournisseur, telephone,  adresse) VALUES (3, 'HWS Menuiserie Technique', '05.60.12.51.61', 'Azazga, entrée Cherfa');
INSERT INTO  fournisseur (id_fournisseur, nom_fournisseur, telephone,  adresse) VALUES (4, 'TIZI OUTILLAGE PROFESSIONNEL Sarl', '05.41.15.37.69', 'Tizi Ouzou, Annar Amallal');
INSERT INTO  fournisseur (id_fournisseur, nom_fournisseur, telephone,  adresse) VALUES (5, 'All Business Impex Eurl', '06.68.23.71.29', 'Ikhelouiene Ait Aissa Mimoun');
INSERT INTO  fournisseur (id_fournisseur, nom_fournisseur, telephone,  adresse) VALUES (6, 'Ets MEHADDI', '05.26.45.66.52', 'Azazga, Yakouren 65 rue Colonel Amirouche');


-- Contenu de la table  produit 
INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(1,'Chaise de cuisine rustique avec assise bois', 'bois massif', 20, 4, 4000, '' );

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(2,'Chaise de brasserie', 'bois simple', 12, 1, 3200, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(3,'Chaise rustique', 'chêne massif', 17, 2, 5000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(4,'Chaise classique', 'chêne massif', 20, 3, 4200, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(5,'Chaise traditionnelle ', 'chêne massif', 14, 6, 3000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(6,'Chaise rustique paille de seigle', 'chêne massif', 10, 1, 3330, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(7,'Chaise avec assise rembourrée', 'bois massif', 14, 1, 5320, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(8,'Tabouret bois rond 4 pieds traditionnel', 'chêne massif', 10, NULL, 2000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(9,'Tabouret de bar', 'chêne massif', 10, 5, 2300, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(10,' Tabouret simple', 'bois de pin', 20, 3, 2000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(11,'Tabouret petit Banc', 'bois massif', 8, 6, 700, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(12,'Banc simple', 'bois ancien', 9, NULL, 1000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(13,'Banc de jardin', 'bois de pin', 7, NULL, 5000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(14,'Poteau carré', 'bois dur', 30, 6, 200, '');
          
INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(15,'Table simple', 'bois massif', 4, NULL, 30000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(16,'Table à manger', 'bois massif', 4, 3, 50000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(17,'Table à manger avec chaise', 'bois massif', 2, 1, 120000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(18,'Table basse vitrée', 'bois massif', 3, NULL, 32000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(19,'Table basse rectangulaire simple', 'bois massif', 4, NULL, 30000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(20,'Table basse rectangulaire avec tiroirs', 'bois massif', 3, NULL, 80000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image) 
VALUES(21,'Table basse ronde avec placage', 'bois massif molene', 5, NULL, 30000, '');

INSERT INTO  produit (id_produit,  nom_produit,  type,  quantite_stock,  id_fournisseur,  prix_unitaire,  image ) 
VALUES(22,'Table d\'appoint ronde', 'bois massif', 8, 4, 6000, '');



-- Contenu de la table  commande
INSERT INTO Commande (id_commande, id_client, date_commande, date_livraison, statut)
VALUES
(1, 1, '2024-12-01 10:30:00', '2024-12-05 15:00:00', 'expédiée'),
(2, 3, '2024-12-03 14:00:00', '2024-12-07 16:30:00', 'en attente'),
(3, 5, '2024-12-04 09:00:00', '2024-12-08 13:00:00', 'annulée'),
(4, 7, '2024-12-05 11:15:00', '2024-12-09 14:45:00', 'annulée'),
(5, 9, '2024-12-06 08:30:00', '2024-12-10 10:30:00', 'expédiée'),
(6, 1, '2024-11-01 08:30:00', '2024-11-07 09:30:00', 'en attente'),
(7, 1, '2024-11-06 08:30:00', '2024-11-10 13:15:00', 'expédiée'),
(8, 3, '2024-10-10 08:30:00', '2024-10-11 11:20:00', 'expédiée');


-- Contenu de la table Achat
INSERT INTO Achat (id_produit, id_commande, quantite_achat, prix_total)
VALUES
(1, 1, 2, 8000),  -- 2 chaises de cuisine rustique à 4000 chacune
(3, 1, 1, 30000),  -- 6 chaise rustique à 5000 chacune
(5, 2, 3, 9000),  -- 3 chaises traditionnelles à 3000 chacune
(6, 3, 1, 3330),  -- 1 chaise rustique paille de seigle
(10, 3, 2, 4000), -- 2 tabourets simples à 2000 chacun
(12, 4, 5, 4000), -- 4 bancs simple à 1000 chacun
(3, 4, 6, 30000),  -- 6 chaise rustique à 5000 chacune
(15, 5, 2, 60000), -- 2 tables simple à 30000 chacun
(17, 5, 2, 240000), -- 2 tables à manger avec chaise à 120000 chacune 
(11, 6, 3, 2100),  -- 3 tabourets petit Banc à 700 chacun
(8, 6, 6, 1200),  -- 6 tabourets bois rond 4 pieds traditionnel à 200 chacun
(19, 7, 3, 90000),  -- 3 tables basse rectangulaire simple à 30000 chacune 
(21, 7, 2, 90000),  -- 3 tables basse ronde avec placage à 30000 chacune
(1, 8, 4, 16000);  -- 4 chaises de cuisine rustique à 4000 chacune




-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;





