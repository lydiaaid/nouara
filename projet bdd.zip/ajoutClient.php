<?php
session_start();
include 'db_conn.php';

$nom_client = $_POST['nom_client'];
$prenom = $_POST['prenom'];
$email = $_POST['email'];
$telephone = $_POST['telephone'];
$adresse = $_POST['adresse'];

//validation simple
if(
    !empty($nom_client) &&
    !empty($prenom) &&
    !empty($email) &&
    !empty($telephone) &&
    !empty($adresse)    
){
    $sql = "INSERT INTO client (nom_client, prenom, email, telephone, adresse) VALUES ('$nom_client', '$prenom', '$email', '$telephone', '$adresse')";

    if($conn->query($sql) === TRUE){
        $_SESSION['message']['text'] = "Client ajouté avec succès";
        $_SESSION['message']['type'] = "success";
    }else{
        $_SESSION['message']['text'] = "une erreur s'est produite lors de l'ajout du client";
        $_SESSION['message']['type'] = "echec";
    }
}else{
    $_SESSION['message']['text'] = "une des information importantes est non renseignée";
    $_SESSION['message']['type'] = "echec";
}

header("Location: clients.php");
exit();