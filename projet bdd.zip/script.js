let sidebar = document.querySelector(".sidebar");
let sidebarBtn = document.querySelector(".sidebarBtn");
sidebarBtn.onclick = function () {
    sidebar.classList.toggle("active");
    if (sidebar.classList.contains("active")) {
        sidebarBtn.classList.replace("bx-menu", "bx-menu-alt-right");
    }else sidebarBtn.classList.replace("bx-menu-alt-right", "bx-menu");
};
    


// Masquer les messages automatiquement après 5 secondes (5000ms)
setTimeout(function() {
    const message = document.querySelector('.message');
    if (message) {
        message.style.opacity = '0'; // Transition pour un effet fluide
        setTimeout(() => message.remove(), 500); // Retirer complètement après 0.5s
    }
}, 5000);