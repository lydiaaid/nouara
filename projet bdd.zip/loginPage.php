<!DOCTYPE html>
<html>
<head>
	<title>AL&F Login</title>
	<link rel="stylesheet" type="text/css" href="css/loginPage.css">
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css"rel="stylesheet"/>
</head>

<body>
    <div class="container">
        <!----------------------------------- welcome ------------------------------->
        <div class="content">
            <h2 class="titre"><img src="imgs/favicon.png" alt="image"> AL&F WOODS</h2>

            <div class="text-sci">
                <h2>Bienvenue! <br> <span>Chez AL&F WOODS MENUISERIE.</span></h2>               
            </div>
        </div>

        <!----------------------------------- login ------------------------------->
        <div class="login">
            <div class="form-box log">
            <form action="loginCheck.php" method="post">
                    <h2>Se connecter</h2>
                    <?php if (isset($_GET['error'])) { ?>
                        <p class="error"><?php echo $_GET['error']; ?></p>
                    <?php } ?>

                    <div class="input-box">
                        <span class="icon"><i class='bx bxs-envelope'></i></span>
                        <input type="text" name="uname" value= "<?php if(empty($uname)) {if (isset($_COOKIE["remember_userName"])) {echo $_COOKIE["remember_userName"];}}?>">
                        <label>Nom Utilisateur</label>
                    </div>

                    <div class="input-box">
                        <span class="icon"><i class="bx bxs-lock-alt"></i></span>
                        <input type="password" name="password">
                        <label>Mot de pass</label>
                    </div>

                    <div class="remenber">
                        <label> <input type="checkbox" name = "remember" <?php if(!empty($remember)) { ?> checked <?php } elseif(isset($_COOKIE["remember"])) { ?> checked <?php } ?>>Se souvenir de moi</label>
                    </div>

                    <button type="submit" class="btn">Se connecter</button>
                </form>  
            </div>
        </div>
    </div>

</body>
</html>