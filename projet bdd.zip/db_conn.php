<?php
// Connexion à la base de données
$sname= "localhost";
$unmae= "root";
$password = "";
$db_name = "test_db";

// Vérification de la connexion
$conn = mysqli_connect($sname, $unmae, $password, $db_name);

if (!$conn) {
	echo "Connection failed!";
}
