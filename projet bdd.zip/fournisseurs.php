<?php
include 'pageAcceuilEntete.php';
?>

<!--------------------------------- Contenaire --------------------------->
<div class="home-content">
    <div class="overview-boxes">
        <div class="box bform">
            <div><h2>Ajouter un fournisseur</h2></div>
            <form action="ajoutFournisseur.php" method="post">
                <label for="nom_fournisseur">Nom</label>
                <input type="text" name="nom_fournisseur" id="nom_fournisseur" placeholder = "veuillez saisir le nom du fournisseur">

                <label for="telephone">Telephone</label>
                <input type="telephone" name="telephone" id="telephone" placeholder="07.80.55.12.01">

                <label for="adresse">Adresse</label>
                <input type="txt" name="adresse" id="adresse" placeholder="veuillez saisir l'adresse du fournisseur ">

                <button type="submit">Valider</button>
                <?php
                    if (isset($_SESSION['message'])) {
                        $type = $_SESSION['message']['type'];
                        $text = $_SESSION['message']['text'];
                        echo "<div class='message $type'>$text</div>";

                        unset($_SESSION['message']);
                    }
                ?>
            </form>
        </div>

        <div class="box tform">
            <!------ table ------>
            <div><h2>Liste des fournisseurs</h2></div>
            <table class="mtable">
                <thead>
                    <tr>
                        <td>Nom fournisseur</td>
                        <td>Telephone</td>
                        <td>Adresse</td>
                    </tr>
                </thead>

                <tbody>
                    <?php
                        // Connexion à la base de données
                        include 'db_conn.php';

                        // Récupération des fournisseurs
                        $sql = "SELECT id_fournisseur, nom_fournisseur, telephone, adresse FROM fournisseur";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['nom_fournisseur']}</td>
                                    <td>{$row['telephone']}</td>
                                    <td>{$row['adresse']}</td>
                                    <td>
                                        <a href='?id_fournisseur={$row['id_fournisseur']}'>
                                            <i class='bx bx-edit-alt'></i>
                                        </a>
                                    </td>  
                                    </tr>";
                            }
                        } 
                        else {
                            echo "<tr><td colspan='3'>Aucun fournisseur trouvé.</td></tr>";
                        }

                        $conn->close();
                        ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</section>

<script>
    // Masquer les messages automatiquement après 5 secondes (5000ms)
    setTimeout(function() {
    const message = document.querySelector('.message');
    if (message) {
        message.style.opacity = '0'; // Transition pour un effet fluide
        setTimeout(() => message.remove(), 30); // Retirer complètement après 0.5s
    }
}, 5000);
</script>