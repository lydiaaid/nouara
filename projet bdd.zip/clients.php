<?php
include 'pageAcceuilEntete.php';
?>

<!--------------------------------- Contenaire --------------------------->
<div class="home-content">
    <div class="overview-boxes">
    <div class="box bform">
            <div><h2>Ajouter un client</h2></div>

            <form action="ajoutClient.php" method="post">
                <label for="nom_client">Nom</label>
                <input type="text" name="nom_client" id="nom_client" placeholder = "veuillez saisir le nom du client">

                <label for="prenom">Prenom</label>
                <input type="prenom" name="prenom" id="prenom" placeholder="veuillez saisir le prenom du client">

                <label for="email">Email</label>
                <input type="txt" name="email" id="email" placeholder="veuillez saisir l'email du client ">

                <label for="telephone">Telephone</label>
                <input type="txt" name="telephone" id="telephone" placeholder="veuillez saisir le telephone du client ">

                <label for="adresse">Adresse</label>
                <input type="txt" name="adresse" id="adresse" placeholder="veuillez saisir l'adresse du client ">

                <button type="submit">Valider</button>
                <?php
                    if (isset($_SESSION['message'])) {
                        $type = $_SESSION['message']['type'];
                        $text = $_SESSION['message']['text'];
                        echo "<div class='message $type'>$text</div>";

                        unset($_SESSION['message']);
                    }
                ?>
            </form>
        </div>

        <div class="box tform">
            <!------ table ------>
            <div><h2>Liste des clients</h2></div>
            <table class="mtable">
                <thead>
                    <tr>
                        <td>Nom</td>
                        <td>Prenom</td>
                        <td>Email</td>
                        <td>Telephone</td>
                        <td>Adresse</td>
                        <td>Action</td>
                    </tr>
                </thead>

                <tbody>
                    <?php
                        // Connexion à la base de données
                        include 'db_conn.php';

                        // Récupération des fournisseurs
                        $sql = "SELECT id_client, nom_client, prenom, email, telephone, adresse FROM client";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['nom_client']}</td>
                                    <td>{$row['prenom']}</td>
                                    <td>{$row['email']}</td>
                                    <td>{$row['telephone']}</td>
                                    <td>{$row['adresse']}</td>
                                    <td>
                                        <a href='?id_client={$row['id_client']}'>
                                            <i class='bx bx-edit-alt'></i>
                                        </a>
                                    </td>   
                                    </tr>";
                            }
                        } 
                        else {
                            echo "<tr><td colspan='3'>Aucun client trouvé.</td></tr>";
                        }

                        $conn->close();
                        ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</section>

<script>
    // Masquer les messages automatiquement après 5 secondes (5000ms)
    setTimeout(function() {
    const message = document.querySelector('.message');
    if (message) {
        message.style.opacity = '0'; // Transition pour un effet fluide
        setTimeout(() => message.remove(), 30); // Retirer complètement après 0.5s
    }
}, 5000);
</script>