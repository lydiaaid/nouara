<?php 
include 'pageAcceuilEntete.php';
?>

<!--------------------------------- Contenaire --------------------------->
    <div class="home-content">
        <!------------------ overview-boxes ----------------->
        <div class="overview-boxes">
          <div class="box">
            <div class="right-side">
              <div class="box-topic">Commande</div>
              <div class="number">40,876</div>
              <div class="indicator">
                <i class="bx bx-up-arrow-alt"></i>
                <span class="text">Depuis hier</span>
              </div>
            </div>
            <i class="bx bx-cart-alt cart"></i>
          </div>

          <div class="box">
            <div class="right-side">
              <div class="box-topic">Vente</div>
              <div class="number">38,876</div>
              <div class="indicator">
                <i class="bx bx-up-arrow-alt"></i>
                <span class="text">Depuis hier</span>
              </div>
            </div>
            <i class="bx bxs-cart-add cart two"></i>
          </div>

          <div class="box">
            <div class="right-side">
              <div class="box-topic">Profit</div>
              <div class="number">12,876</div>
              <div class="indicator">
                <i class="bx bx-up-arrow-alt"></i>
                <span class="text">Depuis hier</span>
              </div>
            </div>
            <i class="bx bx-cart cart three"></i>
          </div>

          <div class="box">
            <div class="right-side">
              <div class="box-topic">Revenu</div>
              <div class="number">11,086</div>
              <div class="indicator">
                <i class="bx bx-down-arrow-alt down"></i>
                <span class="text">Aujourd'hui</span>
              </div>
            </div>
            <i class="bx bxs-cart-download cart four"></i>
          </div>
        </div>

            
            <!-- ================ Order Details List ================= -->
            <div class="details">
              <!------------- recent Orders --------->
              <div class="recentOrders">

                  <!------ titre ------>
                  <div class="cardHeader">
                      <h2>Recent Orders</h2>
                      <a href="#" class="btn">View All</a>
                  </div>
                  
                  <!------ table ------>
                  <table>
                      <thead>
                          <tr>
                              <td>Name</td>
                              <td>Price</td>
                              <td>Payment</td>
                              <td>Status</td>
                          </tr>
                      </thead>

                      <tbody>
                          <tr>
                              <td>Star Refrigerator</td>
                              <td>$1200</td>
                              <td>Paid</td>
                              <td><span class="status delivered">Delivered</span></td>
                          </tr>

                          <tr>
                              <td>Dell Laptop</td>
                              <td>$110</td>
                              <td>Due</td>
                              <td><span class="status pending">Pending</span></td>
                          </tr>

                          <tr>
                              <td>Apple Watch</td>
                              <td>$1200</td>
                              <td>Paid</td>
                              <td><span class="status return">Return</span></td>
                          </tr>

                          <tr>
                              <td>Addidas Shoes</td>
                              <td>$620</td>
                              <td>Due</td>
                              <td><span class="status inProgress">In Progress</span></td>
                          </tr>

                          <tr>
                              <td>Star Refrigerator</td>
                              <td>$1200</td>
                              <td>Paid</td>
                              <td><span class="status delivered">Delivered</span></td>
                          </tr>

                          <tr>
                              <td>Dell Laptop</td>
                              <td>$110</td>
                              <td>Due</td>
                              <td><span class="status pending">Pending</span></td>
                          </tr>

                          <tr>
                              <td>Apple Watch</td>
                              <td>$1200</td>
                              <td>Paid</td>
                              <td><span class="status return">Return</span></td>
                          </tr>

                          <tr>
                              <td>Addidas Shoes</td>
                              <td>$620</td>
                              <td>Due</td>
                              <td><span class="status inProgress">In Progress</span></td>
                          </tr>
                      </tbody>
                  </table>
              </div>

              <!------------- recent Customers ----------->
              <div class="recentCustomers">
                  <!------ titre ------>
                  <div class="table-header">
                      <h2>Produit</h2>
                  </div>

                  <!------ table ------>
                  <table>
                      <thead>
                          <tr>
                              <td>Produit</td>
                              <td>Quantité restante</td>
                          </tr>
                      </thead>
                      <tbody>
                          <tr>
                              <td>Dell Laptop</td>
                              <td>8</td>
                          </tr>                            
                          <tr>
                              <td>Dell Laptop</td>
                              <td>8</td>
                          </tr>
                          <tr>
                              <td>Apple Watch</td>
                              <td>20</td>
                          </tr>
                          <tr>
                              <td>Addidas Shoes</td>
                              <td>5</td>
                          </tr>
                          <tr>
                              <td>Samsung TV</td>
                              <td>12</td>
                          </tr>
                          <tr>
                              <td>Sony Headphones</td>
                              <td>25</td>
                          </tr>
                          <tr>
                              <td>Nike Sneakers</td>
                              <td>10</td>
                          </tr>
                          <tr>
                              <td>HP Printer</td>
                              <td>7</td>
                          </tr>
                      </tbody>
                  </table>
              </div>
          </div>
      </div>
    </section>

    <script src="script.js"></script>