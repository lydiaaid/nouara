<?php 
include 'pageAcceuilEntete.php';
?>

<!--------------------------------- Contenaire --------------------------->
<div class="home-content">
    <div class="overview-boxes">
        <div class="box bform">
           <div><h2>Ajouter un produit</h2></div>
            <form action="" method="post">
                <label for="nom_produit">Nom</label>
                <input type="text" name="nom_produit" id="nom_produit" placeholder = "veuillez saisir le nom du produit">

                <label for="type">Type</label>
                <select name="type" id="type">
                    <option value="chêne_massif">chêne massif</option>  
                    <option value="bois_dur">bois dur</option>
                    <option value="bois_pin">bois de pin</option>
                    <option value="bois_ancien">bois ancien</option>
                    <option value="bois_simple">bois simple</option> 
                    <option value="bois_massif">bois massif</option>     
                    <option value="bois_massif_molene">bois massif molene</option>                
                </select>

                <label for="quantite">Quantité en stock</label>
                <input type="number" name="quantite" id="quantite" placeholder="veuillez saisir la quantité">

                <label for="prix_unitaire">Prix unitaire</label>
                <input type="number" name="prix_unitaire" id="prix_unitaire" placeholder="veuillez saisir le prix">

                <label for="fournisseur">Fournisseur</label>
                <input type="txt" name="fournisseur" id="fournisseur" placeholder="veuillez saisir le nom du fournisseur">

                <button type="submit">Valider</button>
            </form>
        </div>

        <div class="box tform">
            <!------ table ------>
            <div><h2>Listes des produits</h2></div>
            <table class="mtable">
                <thead>
                    <tr>
                        <td>Nom produit</td>
                        <td>Type</td>
                        <td>Quantite</td>
                        <td>Prix unitaire</td>
                        <td>Fournisseur</td>
                        <td>image</td>
                    </tr>
                </thead>

                <tbody>
                    <tr></tr>
                </tbody>

            </table>
        </div>
    </div>
</div>
</section>

<script src="script.js"></script>