<?php 
session_start();

if (!isset($_SESSION['id']) || !isset($_SESSION['user_name'])){
  header("Location: loginPage.php");
  exit();
}
?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="UTF-8" />
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/pageAcceuil.css"/>
    <!-- Boxicons CDN Link -->
    <link href="https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css"rel="stylesheet"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  </head>

  <body>
    <!------------------------------------ Dashbord ------------------------------>
    <div class="sidebar">
      <!----- logo ----->
      <div class="logo-details">
        <img src="imgs/favicon.png" alt="image"> 
        <span class="logo_name">AL&F WOODS</span>
      </div>

      <!----- liens ----->
      <ul class="nav-links">
        <li  class="active">
          <a href="content.php">
            <i class="bx bx-grid-alt"></i>
            <span class="links_name">Dashboard</span>
          </a>
        </li>

        <li>
          <a href="clients.php">
            <i class="bx bx-user"></i>
            <span class="links_name">Clients</span>
          </a>
        </li>  

        <li>
          <a href="fournisseurs.php">
            <i class="bx bx-user"></i>
            <span class="links_name">Fournisseurs</span>
          </a>
        </li>      
        
        <li>
          <a href="produits.php">
            <i class="bx bx-box"></i>
            <span class="links_name">Produits</span>
          </a>
        </li>

        <li>
          <a href="commandes.php">
            <i class="bx bx-list-ul"></i>
            <span class="links_name">Commandes</span>
          </a>
        </li>
<!---
        <li>
          <a href="#">
            <i class="bx bx-pie-chart-alt-2"></i>
            <span class="links_name">Achats</span>
          </a>
        </li>

        <li>
          <a href="#">
            <i class="bx bx-coin-stack"></i>
            <span class="links_name">Stock</span>
          </a>
        </li>
--->
        <!----- logout ----->
        <li class="log_out">
          <a href="logoutCheck.php">
            <i class="bx bx-log-out"></i>
            <span class="links_name">Déconnexion</span>
          </a>
        </li>
      </ul>
    </div>

    <!------------------------------------ Main ------------------------------>
    <section class="home-section">

      <!------------------------ nav bar ----------------->
      <nav>
        <!----- burger menu ----->
        <div class="sidebar-button">
          <i class="bx bx-menu sidebarBtn"></i>
        </div>

        <!----- search ----->
        <div class="search-box">
          <input type="text" placeholder="Recherche..." />
          <i class="bx bx-search"></i>
        </div>

        <!----- profile ----->
        <div class="profile">
          <img src="imgs/customer01.jpg" alt="image"> 
        </div>
      </nav>
