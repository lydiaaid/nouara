<?php
session_start();
include 'db_conn.php';

$nom_fournisseur = $_POST['nom_fournisseur'];
$telephone = $_POST['telephone'];
$adresse = $_POST['adresse'];

//validation simple
if(
    !empty($nom_fournisseur) &&
    !empty($telephone) &&
    !empty($adresse)
){
    $sql = "INSERT INTO fournisseur (nom_fournisseur, telephone, adresse) VALUES ('$nom_fournisseur', '$telephone', '$adresse')";

    if($conn->query($sql) === TRUE){
        $_SESSION['message']['text'] = "Fournisseur ajouté avec succès";
        $_SESSION['message']['type'] = "success";
    }else{
        $_SESSION['message']['text'] = "une erreur s'est produite lors de l'ajout du fournisseur";
        $_SESSION['message']['type'] = "echec";
    }
}else{
    $_SESSION['message']['text'] = "une des information importantes est non renseignée";
    $_SESSION['message']['type'] = "echec";
}

header("Location: fournisseurs.php");
exit();